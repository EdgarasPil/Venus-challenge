import pygame
import random
import mtx_map as mp

class Game:
    def __init__(self):
        # Initialize game
        pygame.init()
        self.Width = 1920*0.5       
        self.Height = 1080*0.5
        ### Size of matrix
        self.rbmap = mp.game.RobotMap
        self.m = len(self.rbmap)
        self.n = len(self.rbmap[0])
        print(self.m)
        print(self.n)
        ### Create ratios
        self.ratio_x = self.Width / self.m
        self.ratio_y = self.Height / self.n
        # Create screen (Width, Height)
        self.screen = pygame.display.set_mode((1920*0.5, 1080*0.5))
        ### Create matrix
        # array = [[0 for i in range(m)] for j in range(n)]

        # Title and Icon
        pygame.display.set_caption("Space Wars")

        # 32 by 32 pixels icon
        self.icon = pygame.image.load("t_gate.png")
        pygame.display.set_icon(self.icon)

        # Player
        self.playerIMG = pygame.image.load("Walle_Avatar.png")
        self.playerIMG = pygame.transform.scale(self.playerIMG, (int(self.ratio_x), int(self.ratio_y)))
        self.playerX, self.playerY = (mp.game.robotOnePosition[1] * self.ratio_x, 
                                      mp.game.robotOnePosition[0] * self.ratio_y)
        self.playerX_change = 0
        self.playerY_change = 0

        self.color_dict = {
            1: self.draw_red,
            2: self.draw_green,
            10: self.draw_white
        }
    
    def draw_red(self, i, j):
         pygame.draw.rect(self.screen, (255, 0, 0), (i - 1, j - 1, 2 * self.ratio_x, 2 * self.ratio_y))
         print(i,j)
    def draw_green(self, i, j):
        pygame.draw.rect(self.screen, (0, 255, 0), (i, j, self.ratio_x, self.ratio_y))

    def draw_white(self, i, j):
        pygame.draw.rect(self.screen, (255, 255, 255), (i, j, self.ratio_x, self.ratio_y))

    def draw_gray(self, i, j):
        pygame.draw.rect(self.screen, (100, 100, 100), (i - 1, j - 1, 2 * self.ratio_x, 2 * self.ratio_y))
        


    def player(self, x, y):
        # Draw image on screen
        self.screen.blit(self.playerIMG, (x, y))
    def run(self):
        # Game Loop
        running = True
        self.screen.fill((249, 194, 26))
        while running:
            
            for event in pygame.event.get():
                # Only closing when the X button is pressed
                if event.type == pygame.QUIT:
                    running = False

                ### Movement of robot
                if event.type == pygame.KEYDOWN:
                #     if event.key == pygame.K_LEFT:
                #         self.playerX_change = -0.7
                #     if event.key == pygame.K_RIGHT:
                #         self.playerX_change = 0.7
                #     if event.key == pygame.K_UP:
                #         self.playerY_change = -0.7
                #     if event.key == pygame.K_DOWN:
                #         self.playerY_change = 0.7
                    if event.key == pygame.K_SPACE:
                        mp.game.run()
                        direction = mp.game.direction
                        ch_x,ch_y = (0,0)
                        print("Direction: ", direction)
                        if direction == "R":
                            self.playerX_change = self.ratio_x
                            self.playerY_change = 0
                            ch_x = 2
                        elif direction == 'L':
                            self.playerX_change = -self.ratio_x
                            self.playerY_change = 0
                            ch_x = -2
                        elif direction == 'U':
                            self.playerY_change = self.ratio_y
                            self.playerX_change = 0
                            ch_y = 2
                        elif direction == 'D':
                            self.playerY_change = -self.ratio_y
                            self.playerX_change = 0
                            ch_y = -2
                    #self.draw_gray(self.playerX,self.playerY)
                    x = int(self.playerX/self.ratio_x) + ch_y
                    y = int(self.playerY/self.ratio_y) + ch_x
                    draw_func = self.color_dict.get(self.rbmap[x][y])
                    draw_func(self.playerX,self.playerY)
                    print("Player position: ", self.playerX, self.playerY)
                    self.playerX += self.playerX_change
                    self.playerY += self.playerY_change
            ### Stop movement
            # if event.type == pygame.KEYUP:
            #     if event.key in (pygame.K_SPACE, pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
            self.playerX_change = 0
            self.playerY_change = 0
            self.playerX += self.playerX_change
            self.playerY += self.playerY_change

            ###Get position of player
            ### Color the square where the player is 
            # Boundaries
            if self.playerX <= 0:
                self.playerX = 0
            elif self.playerX >= self.Width - self.ratio_x:
                self.playerX = self.Width - self.ratio_x
            if self.playerY <= 0:
                self.playerY = 0
            elif self.playerY >= self.Height - self.ratio_y:
                self.playerY = self.Height - self.ratio_y

            self.player(self.playerX, self.playerY)  # Initial position
            pygame.display.update()

        pygame.quit()

# Create an instance of the Game class and run the game
game = Game()
game.run()
