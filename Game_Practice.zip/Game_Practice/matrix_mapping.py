import numpy as np
import matplotlib.pyplot as plt
from collections import deque
from mqtt_host_v2 import MQTTClient
# Initialize the actual map
actualMap = np.array([
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [3, 3, 3, 3, 0, 3, 3, 3, 0, 3],
    [2, 0, 0, 0, 0, 0, 3, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 3, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 3, 0, 2, 2],
    [1, 2, 0, 0, 0, 0, 3, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 3, 0, 0, 0],
    [0, 0, 0, 2, 0, 0, 3, 2, 2, 0],
    [0, 0, 0, 0, 0, 0, 3, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 3, 0, 0, 0]
])

robotOnePosition = [5, 0]  # Initial robot position
canGo10 = 0  # Can go over the same path

# Initialize the RobotMap
RobotMap = np.zeros((10, 10), dtype=int)
RobotMap[robotOnePosition[0]][robotOnePosition[1]] = 1

def printMap():
    global RobotMap, actualMap
    print("Actual Map:")
    print(actualMap)
    print("\nRobot Map:")
    print(RobotMap)

def canGo(pos, direction,mqtt):
    global actualMap, canGo10
    if direction == "R":
        ### Send message
        mqtt.send_message("R")
        message = mqtt.get_message()
        return message
        
        if pos[1] + 1 >= 10:
            return 0
        if RobotMap[pos[0]][pos[1] + 1] == 10 and canGo10 == 0:
            return 0
        if actualMap[pos[0]][pos[1] + 1] == 0:
            return 1
        else:
            RobotMap[pos[0]][pos[1] + 1] = actualMap[pos[0]][pos[1] + 1]
            return 0
    if direction == "L":
        if pos[1] - 1 < 0:
            return 0
        if RobotMap[pos[0]][pos[1] - 1] == 10 and canGo10 == 0:
            return 0
        if actualMap[pos[0]][pos[1] - 1] == 0:
            return 1
        else:
            RobotMap[pos[0]][pos[1] - 1] = actualMap[pos[0]][pos[1] - 1]
            return 0
    if direction == "U":
        if pos[0] + 1 >= 10:
            return 0
        if RobotMap[pos[0] + 1][pos[1]] == 10 and canGo10 == 0:
            return 0
        if actualMap[pos[0] + 1][pos[1]] == 0:
            return 1
        else:
            RobotMap[pos[0] + 1][pos[1]] = actualMap[pos[0] + 1][pos[1]]
            return 0
    if direction == "D":
        if pos[0] - 1 < 0:
            return 0
        if RobotMap[pos[0] - 1][pos[1]] == 10 and canGo10 == 0:
            return 0
        if actualMap[pos[0] - 1][pos[1]] == 0:
            return 1
        else:
            RobotMap[pos[0] - 1][pos[1]] = actualMap[pos[0] - 1][pos[1]]
            return 0

countpaths = 0
paths = []

def getpath(start):
    global paths, countpaths
    
    queue = deque([(start, [])])
    
    while queue and countpaths <= 0:
        pos, path = queue.popleft()
        if pos in path:
            continue
        if pos[0] >= 10 or pos[1] >= 10 or pos[0] < 0 or pos[1] < 0:
            continue
        if RobotMap[pos[0]][pos[1]] == 3:
            continue
        if RobotMap[pos[0]][pos[1]] == 0:
            countpaths += 1
            paths.append(path)
            continue
        if RobotMap[pos[0]][pos[1]] == 10 or RobotMap[pos[0]][pos[1]] == 1:
            new_path = path + [pos]
            queue.append(([pos[0] + 1, pos[1]], new_path))
            queue.append(([pos[0], pos[1] + 1], new_path))
            queue.append(([pos[0] - 1, pos[1]], new_path))
            queue.append(([pos[0], pos[1] - 1], new_path))

def moveRobot(pos, direction):
    global RobotMap, robotOnePosition
    RobotMap[pos[0]][pos[1]] = 10
    if direction == "R":
        RobotMap[pos[0]][pos[1] + 1] = 1
        robotOnePosition = [pos[0], pos[1] + 1]
    elif direction == "L":
        RobotMap[pos[0]][pos[1] - 1] = 1
        robotOnePosition = [pos[0], pos[1] - 1]
    elif direction == "U":
        RobotMap[pos[0] + 1][pos[1]] = 1
        robotOnePosition = [pos[0] + 1, pos[1]]
    elif direction == "D":
        RobotMap[pos[0] - 1][pos[1]] = 1
        robotOnePosition = [pos[0] - 1, pos[1]]
### Define the two robots
broker_address = "mqtt.ics.ele.tue.nl"
topic_publish = "/pynqbridge/37/send"
topic_subscribe = "/pynqbridge/37/send"
username = "Student73"
password = "Ahsha9Oo"
mqtt_client = MQTTClient(broker_address, topic_publish, topic_subscribe, username, password)
mqtt_client.connect()
mqtt_client.start()

while True:
    input("Press Enter to continue...")
    if canGo(robotOnePosition, "U") == 1:
        print("U")
        moveRobot(robotOnePosition, "U")
    elif canGo(robotOnePosition, "R") == 1:
        print("R")
        moveRobot(robotOnePosition, "R")
    elif canGo(robotOnePosition, "D") == 1:
        print("D")
        moveRobot(robotOnePosition, "D")
    elif canGo(robotOnePosition, "L") == 1:
        print("L")
        moveRobot(robotOnePosition, "L")
    else:
        getpath(robotOnePosition)
        print("Got path")
        minlen = float('inf')
        minpath = []

        for p in paths:
            if len(p) < minlen:
                minlen = len(p)
                minpath = p

        for each in minpath:
            direction = ""
            if robotOnePosition[0] < each[0]:
                direction = "U"
            elif robotOnePosition[1] < each[1]:
                direction = "R"
            elif robotOnePosition[0] > each[0]:
                direction = "D"
            elif robotOnePosition[1] > each[1]:
                direction = "L"

            moveRobot(robotOnePosition, direction)
            printMap()
            input("")

        paths = []
        countpaths = 0

    printMap()
