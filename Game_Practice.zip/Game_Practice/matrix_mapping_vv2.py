import numpy as np
from collections import deque
from mqtt_host_v2 import MQTTClient

class MatrixMapping:
    def __init__(self):
        self.actualMap = np.array([
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [3, 3, 3, 3, 0, 3, 3, 3, 0, 3],
            [2, 0, 0, 0, 0, 0, 3, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 3, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 3, 0, 2, 2],
            [1, 2, 0, 0, 0, 0, 3, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 3, 0, 0, 0],
            [0, 0, 0, 2, 0, 0, 3, 2, 2, 0],
            [0, 0, 0, 0, 0, 0, 3, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 3, 0, 0, 0]
        ])
        self.robotOnePosition = [5, 0]  # Initial robot position
        self.canGo10 = 0  # Can go over the same path
        self.RobotMap = np.zeros((10, 10), dtype=int)
        self.RobotMap[self.robotOnePosition[0]][self.robotOnePosition[1]] = 1
        self.countpaths = 0
        self.paths = []
        self.broker_address = "mqtt.ics.ele.tue.nl"
        self.topic_publish = "/pynqbridge/37/send"
        self.topic_subscribe = "/pynqbridge/37/send"
        self.username = "Student73"
        self.password = "Ahsha9Oo"
        self.mqtt_client = MQTTClient(self.broker_address, self.topic_publish, self.topic_subscribe, self.username, self.password)
        self.mqtt_client.connect()
        self.mqtt_client.start()
        self.direction = "R"

    def printMap(self):
        print("\nRobot Map:")
        print(self.RobotMap)

    def updateMap(self, direction, message, pos):
        if direction == "R":
            self.RobotMap[pos[0]][pos[1] + 1] = int(message)
        if direction == "L":
            self.RobotMap[pos[0]][pos[1] - 1] = int(message)
        if direction == "U":
            self.RobotMap[pos[0] + 1][pos[1]] = int(message)
        if direction == "D":
            self.RobotMap[pos[0] - 1][pos[1]] = int(message)

    def canGo(self, pos, direction):
        self.mqtt_client.send_message(direction)
        nomessage = "UURRLLDD"
        message = self.mqtt_client.get_message()
        if pos[0] >= 9 or pos[1] >= 9 or pos[0] < 0 or pos[1] < 0:
            return 1
        while message == None or message in nomessage:
            message = self.mqtt_client.get_message()
            #print(direction, message)

        if message != "0":
            self.updateMap(direction, message, pos)

        return int(message)

    def getpath(self, start):
        queue = deque([(start, [])])

        while queue and self.countpaths <= 0:
            pos, path = queue.popleft()
            if pos in path:
                continue
            if pos[0] >= 10 or pos[1] >= 10 or pos[0] < 0 or pos[1] < 0:
                continue
            if self.RobotMap[pos[0]][pos[1]] == 3:
                continue
            if self.RobotMap[pos[0]][pos[1]] == 0:
                self.countpaths += 1
                self.paths.append(path)
                continue
            if self.RobotMap[pos[0]][pos[1]] == 10 or self.RobotMap[pos[0]][pos[1]] == 1:
                new_path = path + [pos]
                queue.append(([pos[0] + 1, pos[1]], new_path))
                queue.append(([pos[0], pos[1] + 1], new_path))
                queue.append(([pos[0] - 1, pos[1]], new_path))
                queue.append(([pos[0], pos[1] - 1], new_path))

    def moveRobot(self, pos, direction):
        self.RobotMap[pos[0]][pos[1]] = 10
        self.direction = direction
        if direction == "R":
            self.RobotMap[pos[0]][pos[1] + 1] = 1
            self.robotOnePosition = [pos[0], pos[1] + 1]
            self.mqtt_client.send_message("RR")
        elif direction == "L":
            self.RobotMap[pos[0]][pos[1] - 1] = 1
            self.robotOnePosition = [pos[0], pos[1] - 1]
            self.mqtt_client.send_message("LL")
        elif direction == "U":
            self.RobotMap[pos[0] + 1][pos[1]] = 1
            self.robotOnePosition = [pos[0] + 1, pos[1]]
            self.mqtt_client.send_message("UU")
        elif direction == "D":
            self.RobotMap[pos[0] - 1][pos[1]] = 1
            self.robotOnePosition = [pos[0] - 1, pos[1]]
            self.mqtt_client.send_message("DD")

    def run(self):
        #while True:
        #input("Press Enter to continue...")
        print("starts")
        if self.canGo(self.robotOnePosition,"U") == 0:
            print("U")
            self.moveRobot(self.robotOnePosition, "U")
        elif self.canGo(self.robotOnePosition, "R") == 0:
            print("R")
            self.moveRobot(self.robotOnePosition, "R")
        elif self.canGo(self.robotOnePosition, "D") == 0:
            print("D")
            self.moveRobot(self.robotOnePosition, "D")
        elif self.canGo(self.robotOnePosition, "L") == 0:
            print("L")
            self.moveRobot(self.robotOnePosition, "L")
        else:
            self.getpath(self.robotOnePosition)
            print("Got path")
            minlen = float('inf')
            minpath = []

            for p in self.paths:
                if len(p) < minlen:
                    minlen = len(p)
                    minpath = p

            for each in minpath:
                direction = ""
                if self.robotOnePosition[0] < each[0]:
                    direction = "U"
                elif self.robotOnePosition[1] < each[1]:
                    direction = "R"
                elif self.robotOnePosition[0] > each[0]:
                    direction = "D"
                elif self.robotOnePosition[1] > each[1]:
                    direction = "L"

                self.printMap()
                input("")

            self.paths = []
            self.countpaths = 0
        print("It is used")
        self.printMap()

game = MatrixMapping()
#game.run()
