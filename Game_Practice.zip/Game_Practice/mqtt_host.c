///Install MQTT library
/// dotnet add package MQTTnet
using System;
using System.Collections.Concurrent;
using System.Text;
using System.Threading.Tasks;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;

class MQTTClient
{
    private readonly string brokerAddress;
    private readonly string topicPublish;
    private readonly string topicSubscribe;
    private readonly string username;
    private readonly string password;
    private readonly IMqttClient client;
    private readonly ConcurrentQueue<string> receivedMessages;
    private int numMessages;

    public MQTTClient(string brokerAddress, string topicPublish, string topicSubscribe, string username, string password)
    {
        this.brokerAddress = brokerAddress;
        this.topicPublish = topicPublish;
        this.topicSubscribe = topicSubscribe;
        this.username = username;
        this.password = password;
        this.receivedMessages = new ConcurrentQueue<string>();
        this.numMessages = 0;

        var factory = new MqttFactory();
        this.client = factory.CreateMqttClient();

        this.client.UseConnectedHandler(async e =>
        {
            Console.WriteLine("Connected to MQTT Broker!");
            await this.client.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic(topicSubscribe).WithAtMostOnceQoS().Build());
        });

        this.client.UseDisconnectedHandler(e =>
        {
            Console.WriteLine("Disconnected from MQTT Broker.");
        });

        this.client.UseApplicationMessageReceivedHandler(e =>
        {
            var message = Encoding.UTF8.GetString(e.ApplicationMessage.Payload);
            Console.WriteLine($"Received message: {message}");
            if (!string.IsNullOrEmpty(message))
            {
                this.receivedMessages.Enqueue(message);
                this.numMessages++;
            }
        });
    }

    public async Task ConnectAsync()
    {
        var options = new MqttClientOptionsBuilder()
            .WithClientId("MQTT_Example")
            .WithTcpServer(this.brokerAddress, 1883)
            .WithCredentials(this.username, this.password)
            .WithCleanSession()
            .Build();

        try
        {
            await this.client.ConnectAsync(options);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Failed to connect to MQTT broker at {this.brokerAddress}: {e.Message}");
            Environment.Exit(1);
        }
    }

    public async Task PublishMessageAsync(string message)
    {
        var mqttMessage = new MqttApplicationMessageBuilder()
            .WithTopic(this.topicPublish)
            .WithPayload(message)
            .WithExactlyOnceQoS()
            .WithRetainFlag(false)
            .Build();

        await this.client.PublishAsync(mqttMessage);
    }

    public async Task StartAsync()
    {
        await this.client.StartAsync(new MqttClientOptions());
    }

    public async Task StopAsync()
    {
        await this.client.DisconnectAsync();
    }

    public string GetMessage()
    {
        return this.receivedMessages.TryDequeue(out var message) ? message : null;
    }
}

class Program
{
    static async Task Main(string[] args)
    {
        var brokerAddress = "mqtt.ics.ele.tue.nl";
        var topicPublish = "/pynqbridge/37/send";
        var topicSubscribe = "/pynqbridge/37/send";
        var username = "Student73";
        var password = "Ahsha9Oo";

        var mqttClient = new MQTTClient(brokerAddress, topicPublish, topicSubscribe, username, password);
        await mqttClient.ConnectAsync();
        await mqttClient.StartAsync();

        if (args.Length > 0 && args[0] == "1")
        {
            await mqttClient.PublishMessageAsync("Hello MQTT from 01");
        }
        else if (args.Length > 0 && args[0] == "2")
        {
            await mqttClient.PublishMessageAsync("Hello MQTT from 02");
            await mqttClient.PublishMessageAsync("another message");
        }

        while (mqttClient.GetMessage() == null)
        {
            await Task.Delay(4000);
            var message = mqttClient.GetMessage();
            if (message != null)
            {
                Console.WriteLine("Received message: " + message);
            }
        }

        await mqttClient.StopAsync();
    }
}
