import paho.mqtt.client as paho

def messageHandler(client, userdata, message):
    # This function will be called when a message is received
    # Implement your message handling logic here
    ### Get message
    decoded_message = message.payload.decode("utf-8")
    print("Message: ", decoded_message)

class Broker:
    """
    Creates an object that subscribes to MQTT topics and triggers
    a custom method upon receiving a message.
    Args:
        - host: The address of the host.
        - username: username credential.
        - password: password credential.
        - topicSubList (list[str]): List of topics to subscribe to.
        - messageHandler (function): Triggered when a message is received.
    """
    def __init__(self, host, username: str, password: str, topicSubList: list[str], messageHandler: callable) -> None:
        self.client = paho.Client(client_id="clie123")  # Pass a valid client ID
        self.client.username_pw_set(username, password)
        self.client.on_message = messageHandler
        if self.client.connect(host=host) != 0:
            raise RuntimeError("Couldn't connect to the MQTT host")
        try:
            # Check for a successful subscription.
            for topic in topicSubList:
                if self.client.subscribe(topic)[0] != paho.MQTT_ERR_SUCCESS:
                    print(f"Couldn't subscribe to the topic: {topic}")
            # Let an inexperienced user know how to kill the process.
            print("Press CTRL+C to exit...")
            self.client.loop_forever()
        except Exception as error:
            print(error)
        finally:
            print("Disconnecting from the MQTT broker")
            self.client.disconnect()

# The call to loop_forever() is already made inside the Broker class
# No need to call it again here

# To test the messageHandler directly (example):
# Note: This part of the code should not be in production, it's only for testing purposes.
# Create a mock message object to simulate receiving a message
class MockMessage:
    def __init__(self, payload):
        self.payload = payload

# Simulate receiving a message
mock_message = MockMessage(payload=b"Hello World")
messageHandler(broker.client, None, mock_message)
