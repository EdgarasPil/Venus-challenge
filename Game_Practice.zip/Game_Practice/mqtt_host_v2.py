import time
import sys
from collections import deque
import paho.mqtt.client as mqtt

class MQTTClient:
    def __init__(self, broker_address, topic_publish, topic_subscribe, username, password):
        self.broker_address = broker_address
        self.topic_publish = topic_publish
        self.topic_subscribe = topic_subscribe
        self.username = username
        self.password = password
        self.received_messages = deque()
        #self.received_messages = None
        self.num_messages = 0
        self.client = mqtt.Client("MQTT_Example", clean_session=True)
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.username_pw_set(self.username, self.password)

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            #print("Connected to MQTT Broker!")
            client.subscribe(self.topic_subscribe, qos=1)
        else:
            print(f"Failed to connect, return code {rc}\n")

    def on_message(self, client, userdata, message):
        print(str(message.payload.decode("utf-8")))
        if str(message.payload.decode("utf-8")) != None:
            self.received_messages.append(str(message.payload.decode("utf-8")))
            

    def connect(self):
        try:
            self.client.connect(self.broker_address, port=1883)
        except Exception as e:
            print(f"Failed to connect to MQTT broker at {self.broker_address}: {e}")
            exit(1)

    def publish_message(self, message):
        self.client.publish(self.topic_publish, message)

    def start(self):
        self.client.loop_start()
        time.sleep(1)

    def stop(self):
        self.client.loop_stop()
        self.client.disconnect()
    def send_message(self, message):
        self.client.publish(self.topic_publish, message)
    def get_message(self):
        #print(self.received_messages)
        #print(self.received_messages)
        return self.received_messages.popleft() if self.received_messages else None
        #return self.received_messages
# if __name__ == "__main__":
#     broker_address = "mqtt.ics.ele.tue.nl"
#     topic_publish = "/pynqbridge/37/send"
#     topic_subscribe = "/pynqbridge/37/send"
#     username = "Student73"
#     password = "Ahsha9Oo"

#     mqtt_client = MQTTClient(broker_address, topic_publish, topic_subscribe, username, password)
#     mqtt_client.connect()
#     mqtt_client.start()

#     if len(sys.argv) > 1 and sys.argv[1] == "1":
#         mqtt_client.publish_message("Hello MQTT from 01")
#     elif len(sys.argv) > 1 and sys.argv[1] == "2":
#         mqtt_client.publish_message("Hello MQTT from 02")
#         mqtt_client.publish_message("another message")

#     while mqtt_client.num_messages < 1:
#         time.sleep(4)
#         if mqtt_client.received_message:
#             print("Received message:", mqtt_client.get_message())
#             mqtt_client.num_messages += 1

    #mqtt_client.stop()
