import mqtt_host as mhost
import paho.mqtt.client as mqtt
# Instantiate the Broker class with the provided arguments
broker = mhost.Broker(
    "mqtt.ics.ele.tue.nl",  # MQTT broker host
    "Student73",  # Username
    "Ahsha9Oo",  # Password
    ["/pynqbridge/37/SEND", "/pynqbridge/37/SEND"],  # Topics
    mhost.messageHandler  # Message handler function
)
class MQTTClient:
    def __init__(self, broker, port, topic):
        self.received_message = ""
        self.client = mqtt.Client(client_id="client123")
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.broker = broker
        self.port = port
        self.topic = topic

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print("Connected successfully")
            client.subscribe(self.topic)
        else:
            print("Connection failed with code", rc)

    def on_message(self, client, userdata, message):
        self.received_message = message.payload.decode("utf-8")
        print("Message received:", self.received_message)

    def connect_and_subscribe(self):
        self.client.connect(self.broker, self.port, 60)
        self.client.loop_start()

    def stop(self):
        self.client.loop_stop()
        self.client.disconnect()

# Usage
mqtt_client = MQTTClient(broker, port=1883, topic="your/topic")
mqtt_client.connect_and_subscribe()

import time
time.sleep(10)  # Adjust sleep time as needed

# Access the stored message
print("Stored message:", mqtt_client.received_message)

mqtt_client.stop()
