import numpy as np
from collections import deque
from mqtt_host_v2 import MQTTClient

class MatrixMapping:
    def __init__(self):
        self.n = 20
        self.robotOnePosition = [int(self.n / 2), int(self.n / 2)]  # Initial robot position
        self.canGo10 = 0  # Can go over the same path
        self.RobotMap = np.zeros((self.n, self.n), dtype=int)
        self.positions = [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]  # N, NE, E, SE, S, SW, W, NW
        for pos in self.positions:
            self.RobotMap[self.robotOnePosition[0] + pos[0]][self.robotOnePosition[1] + pos[1]] = 1
        self.RobotMap[self.robotOnePosition[0]][self.robotOnePosition[1]] = 1
        self.countpaths = 0
        self.paths = []
        self.broker_address = "mqtt.ics.ele.tue.nl"
        self.topic_publish = "/pynqbridge/37/send"
        self.topic_subscribe = "/pynqbridge/37/send"
        self.username = "Student73"
        self.password = "Ahsha9Oo"
        self.mqtt_client = MQTTClient(self.broker_address, self.topic_publish, self.topic_subscribe, self.username, self.password)
        self.mqtt_client.connect()
        self.mqtt_client.start()
        self.direction = "R"

    def printMap(self):
        print("\nRobot Map:")
        print(self.RobotMap)
    def get_positions(self):
        return self.positions
    def move_robot_position(self, direction):
        if direction == "R":
            self.robotOnePosition[1] += 1
        elif direction == "L":
            self.robotOnePosition[1] -= 1
        elif direction == "U":
            self.robotOnePosition[0] += 1
        elif direction == "D":
            self.robotOnePosition[0] -= 1

        new_positions = [(self.robotOnePosition[0] + pos[0], self.robotOnePosition[1] + pos[1]) for pos in self.positions]
        new_positions.append((self.robotOnePosition[0], self.robotOnePosition[1]))
        print(new_positions)
        for pos in new_positions:
            if 0 <= pos[0] < self.n or 0 <= pos[1] < self.n:
                self.RobotMap[pos[0]][pos[1]] = 1

        if direction == "R":
            for i in range(1, 4):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.robotOnePosition[0] - mv_row][self.robotOnePosition[1] - 2 * mv_col] = 10
        elif direction == "L":
            for i in range(5, 8):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.robotOnePosition[0] - mv_row][self.robotOnePosition[1] - 2 * mv_col] = 10
        elif direction == "U":
            for i in range(3, 6):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.robotOnePosition[0] - 2 * mv_row][self.robotOnePosition[1] + mv_col] = 10
        elif direction == "D":
            for i in (0,1,7):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.robotOnePosition[0] - 2 * mv_row][self.robotOnePosition[1] + mv_col] = 10

    def updateMap(self, direction, message, pos):
        if direction == "R":
            self.RobotMap[pos[0]][pos[1] + 2] = int(message)
        elif direction == "L":
            self.RobotMap[pos[0]][pos[1] - 2] = int(message)
        elif direction == "U":
            self.RobotMap[pos[0] + 2][pos[1]] = int(message)
        elif direction == "D":
            self.RobotMap[pos[0] - 2][pos[1]] = int(message)

    def canGo(self, pos, direction):
        self.mqtt_client.send_message(direction)
        #print(direction)
        nomessage = "UURRLLDD"
        message = self.mqtt_client.get_message()
        if pos[0] + 2 > (self.n - 1) and direction == 'U':
            return 1
        if pos[0] - 2 < 0 and direction == 'D':
            return 1
        if pos[1] + 2 > (self.n - 1) and direction == 'R':
            return 1
        if pos[1] - 2 < 0 and direction == 'L':
            return 1
        while message is None or message in nomessage:
            message = self.mqtt_client.get_message()

        if message != "0":
            self.updateMap(direction, message, pos)

        return int(message)

    def is_valid_position(self, pos):
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                x, y = pos[0] + dx, pos[1] + dy
                if x < 0 or y < 0 or x >= self.n or y >= self.n or self.RobotMap[x][y] == 3:
                    return False
        return True

    def getpath(self, start):
        queue = deque([(start, [])])
        visited = set()

        while queue and self.countpaths <= 0:
            pos, path = queue.popleft()
            if (pos[0], pos[1]) in visited:
                continue
            visited.add((pos[0], pos[1]))

            if self.RobotMap[pos[0]][pos[1]] == 0 and self.is_valid_position(pos):
                self.countpaths += 1
                self.paths.append(path)
                continue

            if self.RobotMap[pos[0]][pos[1]] == 10 or self.RobotMap[pos[0]][pos[1]] == 1:
                new_path = path + [pos]
                for move in [(1, 0), (0, 1), (-1, 0), (0, -1)]:
                    new_pos = [pos[0] + move[0], pos[1] + move[1]]
                    if self.is_valid_position(new_pos):
                        queue.append((new_pos, new_path))

    def moveRobot(self, pos, direction):
        self.direction = direction
        self.move_robot_position(direction)
        self.mqtt_client.send_message(direction + direction)

    def run(self):
        #while True:
            #input("Press Enter to continue...")
            print("starts")
            if self.canGo(self.robotOnePosition, "U") == 0:
                print("U")
                self.moveRobot(self.robotOnePosition, "U")
            elif self.canGo(self.robotOnePosition, "R") == 0:
                print("R")
                self.moveRobot(self.robotOnePosition, "R")
            elif self.canGo(self.robotOnePosition, "D") == 0:
                print("D")
                self.moveRobot(self.robotOnePosition, "D")
            elif self.canGo(self.robotOnePosition, "L") == 0:
                print("L")
                self.moveRobot(self.robotOnePosition, "L")
            else:
                self.getpath(self.robotOnePosition)
                print("Got path")
                minlen = float('inf')
                minpath = []

                for p in self.paths:
                    if len(p) < minlen:
                        minlen = len(p)
                        minpath = p

                for each in minpath:
                    direction = ""
                    if self.robotOnePosition[0] < each[0]:
                        direction = "D"
                    elif self.robotOnePosition[1] < each[1]:
                        direction = "R"
                    elif self.robotOnePosition[0] > each[0]:
                        direction = "U"
                    elif self.robotOnePosition[1] > each[1]:
                        direction = "L"

                    self.printMap()
                    input("")

                self.paths = []
                self.countpaths = 0
            print("It is used")
            self.printMap()

game = MatrixMapping()
#game.printMap()
#game.run()  
    