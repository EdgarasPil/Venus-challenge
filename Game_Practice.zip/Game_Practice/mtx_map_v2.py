### THe new code for matrix map
import numpy as np
from collections import deque
from mqtt_host_v2 import MQTTClient


class MatrixMapping:
    def __init__(self):
        self.n = 20
        self.prev_pos = [int(self.n / 2), int(self.n / 2)]  # Initial robot position
        self.RobotMap = np.zeros((self.n, self.n), dtype=int)
        self.positions = [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]  # N, NE, E, SE, S, SW, W, NW
        self.broker_address = "mqtt.ics.ele.tue.nl"
        self.topic_publish = "/pynqbridge/37/s"
        self.topic_subscribe = "/pynqbridge/37/s"
        self.username = "Student73"
        self.password = "Ahsha9Oo"
        self.mqtt_client = MQTTClient(self.broker_address, self.topic_publish, self.topic_subscribe, self.username, self.password)
        self.mqtt_client.connect()
        self.mqtt_client.start()
        self.changes = {
            (0,1):'D',
            (0,-1):'U',
            (1,0):'R',
            (-1,0):'L'
        }

    def printMap(self):
        print("\nRobot Map:")
        print(self.RobotMap)

    def get_positions(self):
        return self.positions

    def move_robot_position(self, direction, new_pos):
        # if direction == "R":
        #     self.prev_pos[1] += 1
        # elif direction == "L":
        #     self.prev_pos[1] -= 1
        # elif direction == "U":
        #     self.prev_pos[0] += 1
        # elif direction == "D":
        #     self.prev_pos[0] -= 1
        
        self.prev_pos = new_pos

        new_positions = [(self.prev_pos[0] + pos[0], self.prev_pos[1] + pos[1]) for pos in self.positions]
        new_positions.append((self.prev_pos[0], self.prev_pos[1]))
        print(new_positions)
        for pos in new_positions:
            if 0 <= pos[0] < self.n or 0 <= pos[1] < self.n:
                self.RobotMap[pos[0]][pos[1]] = 1

        if direction == "R":
            for i in range(1, 4):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.prev_pos[0] - mv_row][self.prev_pos[1] - 2 * mv_col] = 10
        elif direction == "L":
            for i in range(5, 8):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.prev_pos[0] - mv_row][self.prev_pos[1] - 2 * mv_col] = 10
        elif direction == "U":
            for i in range(3, 6):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.prev_pos[0] - 2 * mv_row][self.prev_pos[1] + mv_col] = 10
        elif direction == "D":
            for i in (0,1,7):
                mv_row, mv_col = self.positions[i]
                self.RobotMap[self.prev_pos[0] - 2 * mv_row][self.prev_pos[1] + mv_col] = 10
        #self.prev_pos = new_pos
        print("prev pos", self.prev_pos)

    def updateMap(self, direction, message, pos):
        if direction == "R":
            self.RobotMap[pos[0]][pos[1] + 2] = int(message)
        elif direction == "L":
            self.RobotMap[pos[0]][pos[1] - 2] = int(message)
        elif direction == "U":
            self.RobotMap[pos[0] + 2][pos[1]] = int(message)
        elif direction == "D":
            self.RobotMap[pos[0] - 2][pos[1]] = int(message)

    def getPos(self):
        print("Getting Position")
        message = self.mqtt_client.get_message()
        while message is None or message == "":
            message = self.mqtt_client.get_message()
        position = ["", ""]
        j = 1
        for i in range(len(message)):
            if message[i] == ",":
                position[j] = int(position[j])
                j -= 1
            else:
                position[j] = position[j]  + message[i]
        position[0] = int(position[0])
        position = self.updatePos(position)
        print(message)
        print(position)
        return position
    
    def updatePos(self, pos):
        return [int(self.n / 2) + pos[0], int(self.n / 2) + pos[1]]

    def get_direction(self, new_pos):
        print("prev", self.prev_pos)
        print("not prev", new_pos)
        diff = (new_pos[0] - self.prev_pos[0], new_pos[1] - self.prev_pos[1])
        print(diff)
        #self.prev_pos = new_pos
        return self.changes[diff] ### Return the directions : R, L, U, D

    def moveRobot(self, pos, direction, new_pos):
        self.direction = direction
        #self.prev_pos = pos
        self.move_robot_position(direction, new_pos)
        #self.printMap()
        #self.mqtt_client.send_message(direction + direction)

    def run(self):
        #while True:
            #input("Press Enter to continue...")
            print("starts")
            new_pos = self.getPos()
            self.moveRobot(self.prev_pos, self.get_direction(new_pos), new_pos)
            self.printMap()

game = MatrixMapping()
while True:
    game.run()
# game.run()
#game.printMap()
#game.run()  
    