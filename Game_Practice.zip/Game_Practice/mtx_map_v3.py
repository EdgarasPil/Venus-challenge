import numpy as np
from mqtt_host_v2 import MQTTClient


class MatrixMapping:
    def __init__(self):
        self.n = 20
        self.message = ""
        self.prev_pos = [int(self.n / 2), int(self.n / 2)]  # Initial robot position
        self.RobotMap = np.zeros((self.n, self.n), dtype=int)
        self.positions = [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]  # N, NE, E, SE, S, SW, W, NW
        self.broker_address = "mqtt.ics.ele.tue.nl"
        self.topic_publish = "/pynqbridge/37/s"
        self.topic_subscribe = "/pynqbridge/37/s"
        self.username = "Student73"
        self.password = "Ahsha9Oo"
        self.mqtt_client = MQTTClient(self.broker_address, self.topic_publish, self.topic_subscribe, self.username, self.password)
        self.mqtt_client.connect()
        self.mqtt_client.start()
        self.changes = {
            (0,1):'R',
            (0,-1):'L',
            (1,0):'D',
            (-1,0):'U'
        }

    def printMap(self):
        print("\nRobot Map:")
        print(self.RobotMap)

    def move_robot_position(self, direction, new_pos):
        self.prev_pos = new_pos

        new_positions = [(self.prev_pos[0] + pos[0], self.prev_pos[1] + pos[1]) for pos in self.positions]
        new_positions.append((self.prev_pos[0], self.prev_pos[1]))

        for pos in new_positions:
            if 0 <= pos[0] < self.n and 0 <= pos[1] < self.n:
                self.RobotMap[pos[0]][pos[1]] = 1

        if direction == "R":
            for i in range(1, 4):
                mv_row, mv_col = self.positions[i]
                if 0 <= self.prev_pos[0] - mv_row < self.n and 0 <= self.prev_pos[1] - 2 * mv_col < self.n:
                    self.RobotMap[self.prev_pos[0] - mv_row][self.prev_pos[1] - 2 * mv_col] = 10
        elif direction == "L":
            for i in range(5, 8):
                mv_row, mv_col = self.positions[i]
                if 0 <= self.prev_pos[0] - mv_row < self.n and 0 <= self.prev_pos[1] - 2 * mv_col < self.n:
                    self.RobotMap[self.prev_pos[0] - mv_row][self.prev_pos[1] - 2 * mv_col] = 10
        elif direction == "U":
            for i in range(3, 6):
                mv_row, mv_col = self.positions[i]
                if 0 <= self.prev_pos[0] - 2 * mv_row < self.n and 0 <= self.prev_pos[1] + mv_col < self.n:
                    self.RobotMap[self.prev_pos[0] - 2 * mv_row][self.prev_pos[1] + mv_col] = 10
        elif direction == "D":
            for i in (0, 1, 7):
                mv_row, mv_col = self.positions[i]
                if 0 <= self.prev_pos[0] - 2 * mv_row < self.n and 0 <= self.prev_pos[1] + mv_col < self.n:
                    self.RobotMap[self.prev_pos[0] - 2 * mv_row][self.prev_pos[1] + mv_col] = 10

        print("prev pos", self.prev_pos)

    def updateMap(self, direction, message, pos):
        if direction == "R" and pos[1] + 2 < self.n:
            self.RobotMap[pos[0]][pos[1] + 2] = int(message)
        elif direction == "L" and pos[1] - 2 >= 0:
            self.RobotMap[pos[0]][pos[1] - 2] = int(message)
        elif direction == "U" and pos[0] + 2 < self.n:
            self.RobotMap[pos[0] + 2][pos[1]] = int(message)
        elif direction == "D" and pos[0] - 2 >= 0:
            self.RobotMap[pos[0] - 2][pos[1]] = int(message)

    def getPos(self):
        print("Getting Position")
        #message = self.mqtt_client.get_message()
        message = input("")
        while message is None or message == "":
            message = self.mqtt_client.get_message()
            #print(message)

        position = message.split(',')
        position = [int(position[0]), int(position[1])]
        position = self.updatePos(position)
        print(message)
        print(position)
        return position
    
    def updatePos(self, pos):
        return [int(self.n / 2) + pos[0], int(self.n / 2) + pos[1]]

    def get_direction(self, new_pos):
        print("prev", self.prev_pos)
        print("not prev", new_pos)
        diff = (new_pos[0] - self.prev_pos[0], new_pos[1] - self.prev_pos[1])
        print(diff)
        return self.changes[diff]

    def get_ori(self,message):
        ori = ""
        ori_array = ["N", "W", "S", "E"]
        for character in range(len(self.message)):
            for element in ori_array:
                if self.message[character] == element:
                    return element

    def moveRobot(self, pos, direction, new_pos):
        self.move_robot_position(direction, new_pos)

    def run(self):
        print("starts")
        new_pos = self.getPos()
        self.moveRobot(self.prev_pos, self.get_direction(new_pos), new_pos)
        self.printMap()


game = MatrixMapping()
print(game.get_ori("0,1,W"))
while True:
    game.run()
