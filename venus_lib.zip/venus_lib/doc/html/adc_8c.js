var adc_8c =
[
    [ "adc_destroy", "group__ADC.html#ga879cfdbd930b0d6cb3668d63a5a41265", null ],
    [ "adc_init", "group__ADC.html#ga2b815e6730e8723a6d1d06d9ef8f31c0", null ],
    [ "adc_read_channel", "group__ADC.html#ga3b240634d5b05f4081287644d6a8a60d", null ],
    [ "adc_read_channel_raw", "group__ADC.html#ga6445090781b49f628c788ba3d9745853", null ],
    [ "check_channel_adc", "adc_8c.html#af1193b8b8fc22626189c3de755e9fd6e", null ],
    [ "check_initialized_adc", "adc_8c.html#abfec0c3da1defecc0e7f60079f6e59eb", null ],
    [ "initialized_adc", "group__ADC.html#ga36aebf58ac4baaa01a3a2a6f3bc209e3", null ],
    [ "invalid_channel_adc", "adc_8c.html#a4a0ad2510ea95f0dafa8303567671689", null ]
];