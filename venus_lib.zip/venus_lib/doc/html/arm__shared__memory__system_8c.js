var arm__shared__memory__system_8c =
[
    [ "arm_shared_close", "group__ARMSHARED.html#ga12c3557dfcb0ebbf3386b52068c56618", null ],
    [ "arm_shared_init", "group__ARMSHARED.html#gab5254fff75e33f677c5a4b0c0f401f10", null ]
];