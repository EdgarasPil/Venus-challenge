var audio_8c =
[
    [ "LOG_DOMAIN", "audio_8c.html#a95a1d08c807e0aada863b5298a61d08d", null ],
    [ "SAMPLE_RATE", "audio_8c.html#a4b76a0c2859cfd819a343a780070ee2b", null ],
    [ "audio_bypass", "group__AUDIO.html#ga5fee8d77c208512f18f4273213520249", null ],
    [ "audio_generate_tone", "group__AUDIO.html#ga061d146b990619c8f7ebd37ee18cbe23", null ],
    [ "audio_init", "group__AUDIO.html#ga780026a09284372732eeca5c1bdeda0b", null ],
    [ "audio_play", "group__AUDIO.html#ga52d0f4ea75ee4d027430bb25a2f8b7a9", null ],
    [ "audio_record", "group__AUDIO.html#ga1d91ff881ec020a63e36e4f285622b80", null ],
    [ "audio_record_response", "group__AUDIO.html#gae570f6615745d48d3fbb0bdd30195a27", null ],
    [ "audio_record_response_start", "group__AUDIO.html#ga4ee83180ef77ba88e6426f8eb6f197ef", null ],
    [ "audio_repeat_play", "group__AUDIO.html#ga4b430bbc9a47b8160f2596cc625683ff", null ],
    [ "audio_select_input", "group__AUDIO.html#ga61af1e13a8f338966a17f07a518ef207", null ],
    [ "config_audio_codec", "group__AUDIO.html#ga4c3476adecb27a3162fabab4af088f0b", null ],
    [ "config_audio_pll", "group__AUDIO.html#ga9c9de79126611d05d3e2bda897ca886e", null ],
    [ "deselect", "group__AUDIO.html#ga0ae77235b32f5522d5d881baf2c52210", null ],
    [ "read_audio_reg", "audio_8c.html#a543110eb76ac847e8be875e2cfb0fbc1", null ],
    [ "select_line_in", "group__AUDIO.html#gaec4645b89d23204e90f880d09da94525", null ],
    [ "select_mic", "group__AUDIO.html#ga2203ea82d55c60566ab868a82292aedf", null ],
    [ "write_audio_reg", "group__AUDIO.html#ga3ec4d5593965dc8b93d40e80e2143902", null ]
];