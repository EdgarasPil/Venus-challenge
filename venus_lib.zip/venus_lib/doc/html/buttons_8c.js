var buttons_8c =
[
    [ "LOG_DOMAIN", "buttons_8c.html#a95a1d08c807e0aada863b5298a61d08d", null ],
    [ "buttons_destroy", "group__BUTTONS.html#ga3633aee67ac18052de38fb71d13811f3", null ],
    [ "buttons_init", "group__BUTTONS.html#gacef6dd444cb6560da652897ee43ab306", null ],
    [ "get_button_state", "group__BUTTONS.html#gacc476636216862a61ee78201a3bbe92f", null ],
    [ "get_switch_state", "group__BUTTONS.html#gac9f62ce663ac190adcc8f2a1df5922fd", null ],
    [ "sleep_msec_button_pushed", "group__BUTTONS.html#ga0cfd4ec403dbb078a31457c34d8e1268", null ],
    [ "sleep_msec_buttons_pushed", "group__BUTTONS.html#gaf3139cee17ab0d39792d4ed111173854", null ],
    [ "switches_destroy", "group__BUTTONS.html#ga6fd5f582221b6e55722ed8651fcd3617", null ],
    [ "switches_init", "group__BUTTONS.html#ga1e5ebcb346c25e1755e3ccb1e9f3c9f9", null ],
    [ "wait_until_any_button_pushed", "group__BUTTONS.html#ga3249cfa7eaa3dc7217b466e2bd1d6067", null ],
    [ "wait_until_any_button_released", "group__BUTTONS.html#ga5c79a6880ef76e1f96407fb9a1aa8774", null ],
    [ "wait_until_button_pushed", "group__BUTTONS.html#ga1635729112b5af83feee6a4255cc2373", null ],
    [ "wait_until_button_released", "group__BUTTONS.html#gaa3646a1a39ebd3d5d8f375c4352e4d8b", null ],
    [ "wait_until_button_state", "group__BUTTONS.html#ga75a555075662ca2a8a4be526adeb37b3", null ]
];