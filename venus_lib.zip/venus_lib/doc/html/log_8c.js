var log_8c =
[
    [ "DOMAIN", "log_8c.html#a5467ce86fff063609c6ae5b8dc517471", null ],
    [ "pynq_log", "group__LOG.html#ga190ef46bdfa0f8b5bddb785f2b685673", null ]
];