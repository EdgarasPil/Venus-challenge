var pulsecounter_8h =
[
    [ "pulsecounter_index_t", "group__PULSECOUNTER.html#ga21bff7b95833507fa453e5a3ee77e454", [
      [ "PULSECOUNTER0", "group__PULSECOUNTER.html#gga21bff7b95833507fa453e5a3ee77e454a4ffcf3fa606e894fd182b51755c4a30c", null ],
      [ "PULSECOUNTER1", "group__PULSECOUNTER.html#gga21bff7b95833507fa453e5a3ee77e454a9b69944315d6e601a94c34b7f09d56c8", null ],
      [ "NUM_PULSECOUNTERS", "group__PULSECOUNTER.html#gga21bff7b95833507fa453e5a3ee77e454a6e8ac04d9cc1b93cb4fc7260b81f4bf5", null ]
    ] ],
    [ "pulsecounter_destroy", "group__PULSECOUNTER.html#ga74e8db65985f142e0724681a8e171f67", null ],
    [ "pulsecounter_get_count", "group__PULSECOUNTER.html#ga8af81b44f69d39655574047ef0abeb8d", null ],
    [ "pulsecounter_get_edge", "group__PULSECOUNTER.html#gaf1d9a614daa4d4438747962f8b584bef", null ],
    [ "pulsecounter_get_filter_length", "group__PULSECOUNTER.html#gab938b3769b85b7d9cbc030086773585e", null ],
    [ "pulsecounter_init", "group__PULSECOUNTER.html#gaa6e9e9e62511cc01725f80d2297d02ab", null ],
    [ "pulsecounter_reset_count", "group__PULSECOUNTER.html#ga065eaf9347ba3fa9d18af985f1ca77c0", null ],
    [ "pulsecounter_set_edge", "group__PULSECOUNTER.html#gad6d62b8a5fa9ea2d6061d866c65d88d8", null ],
    [ "pulsecounter_set_filter_length", "group__PULSECOUNTER.html#ga42cd91da275682dd07c82eebda3c93f4", null ]
];