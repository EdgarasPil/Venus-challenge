var searchData=
[
  ['fontxdebug_1379',['FontxDebug',['../fontx_8c.html#a7ddc949c2147f61bf01b9f72b684cf1a',1,'fontx.c']]],
  ['fontxglyphbufsize_1380',['FontxGlyphBufSize',['../fontx_8h.html#a2b6faf212a76ed7ab3cb7f16357e1f27',1,'fontx.h']]]
];
