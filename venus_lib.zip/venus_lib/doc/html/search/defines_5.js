var searchData=
[
  ['libpynq_5frelease_1422',['LIBPYNQ_RELEASE',['../version_8c.html#a037b4364564ecb4da6ae15514afbbdf5',1,'version.c']]],
  ['libpynq_5fversion_5fmajor_1423',['LIBPYNQ_VERSION_MAJOR',['../version_8c.html#a0b090cbb9d88943d8a196c2fafef9dae',1,'version.c']]],
  ['libpynq_5fversion_5fminor_1424',['LIBPYNQ_VERSION_MINOR',['../version_8c.html#a8c734c9905dab64821b8675cee25e544',1,'version.c']]],
  ['libpynq_5fversion_5fpatch_1425',['LIBPYNQ_VERSION_PATCH',['../version_8c.html#a9d275b5b9e28b96c4c5c01f52abf8b9d',1,'version.c']]],
  ['log_5fdomain_1426',['LOG_DOMAIN',['../audio_8c.html#a95a1d08c807e0aada863b5298a61d08d',1,'LOG_DOMAIN():&#160;audio.c'],['../buttons_8c.html#a95a1d08c807e0aada863b5298a61d08d',1,'LOG_DOMAIN():&#160;buttons.c'],['../display_8c.html#a95a1d08c807e0aada863b5298a61d08d',1,'LOG_DOMAIN():&#160;display.c'],['../leds_8c.html#a95a1d08c807e0aada863b5298a61d08d',1,'LOG_DOMAIN():&#160;leds.c'],['../log_8h.html#a95a1d08c807e0aada863b5298a61d08d',1,'LOG_DOMAIN():&#160;log.h'],['../version_8c.html#a95a1d08c807e0aada863b5298a61d08d',1,'LOG_DOMAIN():&#160;version.c']]]
];
