var searchData=
[
  ['sample_5frate_1430',['SAMPLE_RATE',['../audio_8c.html#a4b76a0c2859cfd819a343a780070ee2b',1,'audio.c']]],
  ['stepper_5freg_5fconfig_1431',['STEPPER_REG_CONFIG',['../stepper_8c.html#ae297a9d1a19ef861293689cf43176642',1,'stepper.c']]],
  ['stepper_5freg_5fcount_1432',['STEPPER_REG_COUNT',['../stepper_8c.html#a5cf9e876f4e9fd96e858aceacf67b545',1,'stepper.c']]],
  ['stepper_5freg_5fcur_5fduty_1433',['STEPPER_REG_CUR_DUTY',['../stepper_8c.html#a8fad156a2c5f5f084874434861500509',1,'stepper.c']]],
  ['stepper_5freg_5fcur_5fperiod_1434',['STEPPER_REG_CUR_PERIOD',['../stepper_8c.html#a85b10d8a5d9f66d99b1c66c404350757',1,'stepper.c']]],
  ['stepper_5freg_5fcur_5fsteps_1435',['STEPPER_REG_CUR_STEPS',['../stepper_8c.html#a4ecdec5c56721648cf04d6a00f200b45',1,'stepper.c']]],
  ['stepper_5freg_5fduty_1436',['STEPPER_REG_DUTY',['../stepper_8c.html#a0abdaed095ac4d4fc9e0345760d2412a',1,'stepper.c']]],
  ['stepper_5freg_5fnxt_5fduty_1437',['STEPPER_REG_NXT_DUTY',['../stepper_8c.html#a5ddc5e64a81707676569990013877d52',1,'stepper.c']]],
  ['stepper_5freg_5fnxt_5fperiod_1438',['STEPPER_REG_NXT_PERIOD',['../stepper_8c.html#ae837f1e5cbd010179d2e0859505be532',1,'stepper.c']]],
  ['stepper_5freg_5fnxt_5fsteps_1439',['STEPPER_REG_NXT_STEPS',['../stepper_8c.html#a84f520f53137c69659fa3d8896e17bf0',1,'stepper.c']]],
  ['stepper_5freg_5fperiod_1440',['STEPPER_REG_PERIOD',['../stepper_8c.html#abc9c9745cc9fd68c01c1ddcf20d59cfe',1,'stepper.c']]],
  ['stepper_5freg_5fsteps_1441',['STEPPER_REG_STEPS',['../stepper_8c.html#a2e36f876f94bd4f038cbb8bdced353ac',1,'stepper.c']]],
  ['synchronize_5fio_1442',['SYNCHRONIZE_IO',['../xil__io_8h.html#a434d3cb7a50893db67fca751a8fff2b8',1,'xil_io.h']]]
];
