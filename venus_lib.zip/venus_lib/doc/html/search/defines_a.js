var searchData=
[
  ['writei2c_5fbyte_1455',['writeI2C_byte',['../i2cps_8h.html#ad2943741fa4adcaac843c6577ba9de6e',1,'i2cps.h']]],
  ['writei2c_5fword_1456',['writeI2C_word',['../i2cps_8h.html#a22e6f58178ffd3a325dbb36c22b114cf',1,'i2cps.h']]]
];
