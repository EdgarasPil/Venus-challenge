var searchData=
[
  ['adc_5fchannel_5ft_1123',['adc_channel_t',['../group__ADC.html#gaafc4060027875f8fe46242b0656d7814',1,'adc.h']]],
  ['audio_5fadau1761_5fregs_1124',['audio_adau1761_regs',['../group__AUDIO.html#ga0bd369c0b189e481157749038dea1ca0',1,'audio.h']]]
];
