var searchData=
[
  ['color_5fled_5findex_5ft_1126',['color_led_index_t',['../group__LEDS.html#ga5d0e2415131d5a46bf054c9adfafd12d',1,'leds.h']]],
  ['colors_1127',['colors',['../group__DISPLAY.html#gaedd64c3f92da850b93776c65fd1cced3',1,'display.h']]]
];
