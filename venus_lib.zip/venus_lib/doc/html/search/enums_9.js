var searchData=
[
  ['spi_5fmode_5ft_1140',['spi_mode_t',['../display_8c.html#ac4b206a51636d91c5cffcbcee458c3cb',1,'display.c']]],
  ['switches_5findex_5ft_1141',['switches_index_t',['../group__BUTTONS.html#ga426bebe7ddc81f4c7a7e1853b20fe17b',1,'buttons.h']]]
];
