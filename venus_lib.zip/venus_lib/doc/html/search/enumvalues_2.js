var searchData=
[
  ['color_5fled0_1154',['COLOR_LED0',['../group__LEDS.html#gga5d0e2415131d5a46bf054c9adfafd12daa904ee289032d5569f7a54d7e09e560a',1,'leds.h']]],
  ['color_5fled1_1155',['COLOR_LED1',['../group__LEDS.html#gga5d0e2415131d5a46bf054c9adfafd12da8d321151b19bbcbe86e91c86bccac8dc',1,'leds.h']]]
];
