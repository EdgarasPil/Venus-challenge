var searchData=
[
  ['num_5fbuttons_1238',['NUM_BUTTONS',['../group__BUTTONS.html#gga711eeb98ffdbaaaeed9fd7b659b3d83bac81067fe4db9cdff7042b4d9efb5f4cb',1,'buttons.h']]],
  ['num_5fcolor_5fleds_1239',['NUM_COLOR_LEDS',['../group__LEDS.html#gga5d0e2415131d5a46bf054c9adfafd12dadc8540083826abd7b1fe0ce3d509c8a8',1,'leds.h']]],
  ['num_5fgreen_5fleds_1240',['NUM_GREEN_LEDS',['../group__LEDS.html#ggada10100f8d1cafd5374fd6bef470b719a9d90fb1b1a63db309f0b7021da5b4b56',1,'leds.h']]],
  ['num_5fiics_1241',['NUM_IICS',['../group__IIC.html#gga07f0557e9d560deb1df586ddbdfaf58aae108f4ddbc77b2e14e71cf9392be12c0',1,'iic.h']]],
  ['num_5fio_5fconfigurations_1242',['NUM_IO_CONFIGURATIONS',['../group__SWITCHBOX.html#gga0eb2b30968ee6d2206889ba667fc47b9a4046d179bf5542168dbd0834ff69bee9',1,'switchbox.h']]],
  ['num_5flog_5flevels_1243',['NUM_LOG_LEVELS',['../group__LOG.html#ggaca1fd1d8935433e6ba2e3918214e07f9a4ffba60acdbb6fe4c6acf32b06d065d0',1,'log.h']]],
  ['num_5fpulsecounters_1244',['NUM_PULSECOUNTERS',['../group__PULSECOUNTER.html#gga21bff7b95833507fa453e5a3ee77e454a6e8ac04d9cc1b93cb4fc7260b81f4bf5',1,'pulsecounter.h']]],
  ['num_5fpwms_1245',['NUM_PWMS',['../group__PWM.html#gga7c7cbd95febb3ce3be12a45174fc67bda3048305dcd0e054024ae8b136283152d',1,'pwm.h']]],
  ['num_5fswitches_1246',['NUM_SWITCHES',['../group__BUTTONS.html#gga426bebe7ddc81f4c7a7e1853b20fe17ba30feaf3abb229ebb97fce793cbecae56',1,'buttons.h']]],
  ['num_5ftext_5fdirections_1247',['NUM_TEXT_DIRECTIONS',['../group__DISPLAY.html#gga94c73cf6934fd835103f0f2794071ee9a6658d36a1bd0b801aba13a69ae3e8720',1,'display.h']]],
  ['num_5fuarts_1248',['NUM_UARTS',['../group__UART.html#gga45928ea0a0c86049068887d70beab0d3a7e7cb082201c15a1b5d34c81b74bd69d',1,'uart.h']]]
];
