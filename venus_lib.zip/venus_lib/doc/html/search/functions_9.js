var searchData=
[
  ['mapping_5finfo_963',['mapping_info',['../group__UTIL.html#gad14cbdc178718d358180c9a1cf83cfc0',1,'mapping_info(void):&#160;util.c'],['../group__UTIL.html#gad14cbdc178718d358180c9a1cf83cfc0',1,'mapping_info(void):&#160;util.c']]]
];
