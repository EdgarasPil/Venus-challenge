var searchData=
[
  ['openfontx_964',['OpenFontx',['../group__FONTX.html#gad919094a18ac1d85c85f741c31a3dc00',1,'OpenFontx(FontxFile *fx):&#160;fontx.c'],['../group__FONTX.html#gad919094a18ac1d85c85f741c31a3dc00',1,'OpenFontx(FontxFile *fx):&#160;fontx.c']]]
];
