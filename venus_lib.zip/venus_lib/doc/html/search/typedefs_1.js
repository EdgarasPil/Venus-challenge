var searchData=
[
  ['file_1117',['FILE',['../group__FONTX.html#ga912af5ab9f8a52ddd387b7defc0b49f1',1,'fontx.h']]]
];
