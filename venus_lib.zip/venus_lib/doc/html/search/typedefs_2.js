var searchData=
[
  ['iichandle_1118',['IICHandle',['../iic_8c.html#a4bdcb7645329291d53f6686078a75e8d',1,'iic.c']]],
  ['io_5fconfiguration_5ft_1119',['io_configuration_t',['../group__SWITCHBOX.html#gaff5256ebf82f8c6a10cfd668b91e0fe3',1,'switchbox.h']]]
];
