var searchData=
[
  ['_5fbl_1050',['_bl',['../structdisplay__t.html#a4732447bbd81c6b8692460ad2db1cc99',1,'display_t']]],
  ['_5fdc_1051',['_dc',['../structdisplay__t.html#a4974a8aedfe8a5dfc5dc39da5ae03648',1,'display_t']]],
  ['_5ffont_5fdirection_1052',['_font_direction',['../structdisplay__t.html#a3806b5245365c837c9fa5901c41a4266',1,'display_t']]],
  ['_5ffont_5ffill_1053',['_font_fill',['../structdisplay__t.html#a0ffc7035e9cb798b1d94e44a45724e39',1,'display_t']]],
  ['_5ffont_5ffill_5fcolor_1054',['_font_fill_color',['../structdisplay__t.html#a0c35ebf599ec6a7ee21ba21b1c253674',1,'display_t']]],
  ['_5ffont_5funderline_1055',['_font_underline',['../structdisplay__t.html#aa073e0a47dbf3a1a3d561872f8de1a6d',1,'display_t']]],
  ['_5ffont_5funderline_5fcolor_1056',['_font_underline_color',['../structdisplay__t.html#a8808b4e68173017536db3becfb71f92b',1,'display_t']]],
  ['_5fheight_1057',['_height',['../structdisplay__t.html#ad4317ca0108d24847429ee10c9087118',1,'display_t']]],
  ['_5foffsetx_1058',['_offsetx',['../structdisplay__t.html#af4a87ab49f86ff78ca6626a1e79167da',1,'display_t']]],
  ['_5foffsety_1059',['_offsety',['../structdisplay__t.html#a18910060714067b9411d749d12348a0d',1,'display_t']]],
  ['_5fwidth_1060',['_width',['../structdisplay__t.html#a26768f13f25a76f85a72f5ccfc04dd0b',1,'display_t']]]
];
