var searchData=
[
  ['file_1065',['file',['../structFontxFile.html#acfa31c033f181df833797e43f817fe10',1,'FontxFile']]],
  ['file_5fdescriptor_1066',['file_descriptor',['../structarm__shared__t.html#a73bb1611ec7df55b9b986af1cd288201',1,'arm_shared_t']]],
  ['fsz_1067',['fsz',['../structFontxFile.html#a6d68646b456c2f398c88f199e3f24b05',1,'FontxFile']]],
  ['fxname_1068',['fxname',['../structFontxFile.html#a9da66358e5f22eee0036da68e1a05ce7',1,'FontxFile']]]
];
