var searchData=
[
  ['intc0_1071',['intc0',['../gpio_8c.html#a77025f1b445602df9f8e0709ffca31fb',1,'intc0():&#160;gpio.c'],['../interrupt_8c.html#aa0a558bb64e720557baf9d4054585057',1,'intc0():&#160;gpio.c']]],
  ['ioswitch_1072',['ioswitch',['../switchbox_8c.html#ab2b7250f7c587c4f762accaea12eb148',1,'switchbox.c']]],
  ['ioswitch_5fhandle_1073',['ioswitch_handle',['../switchbox_8c.html#af3add057b8db7797b5d5a1f5a6e1f38c',1,'switchbox.c']]],
  ['is_5fank_1074',['is_ank',['../structFontxFile.html#a8c88603516317fac8eee19b5049d3819',1,'FontxFile']]]
];
