var searchData=
[
  ['major_1079',['major',['../structversion__t.html#a416baed41342720bbbca73a2c7b4926f',1,'version_t']]],
  ['mem_5fhandle_1080',['mem_handle',['../structIICHandle.html#aadf4b2abce977a03980a46fdc108f1e0',1,'IICHandle']]],
  ['minor_1081',['minor',['../structversion__t.html#ae0ceed5598105d0b6bef201bd06d910c',1,'version_t']]],
  ['mmaped_5fregion_1082',['mmaped_region',['../structarm__shared__t.html#a8cdf9fb06e80f6dfadd2d1f03994bf1b',1,'arm_shared_t']]]
];
