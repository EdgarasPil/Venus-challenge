var searchData=
[
  ['name_1083',['name',['../structpin.html#a83d27e14d4dd6e48b483bb4a744eea00',1,'pin::name()'],['../structpin__state__t.html#a495d1da64ba88ecb831012debdb6dd7f',1,'pin_state_t::name()']]],
  ['new_5fval_1084',['new_val',['../structIICHandle.html#acdd859854589b739e95f8bb12ca29507',1,'IICHandle']]]
];
