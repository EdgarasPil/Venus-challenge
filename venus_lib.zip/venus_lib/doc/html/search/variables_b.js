var searchData=
[
  ['opened_1085',['opened',['../structFontxFile.html#abbe390075007bfcbf7b947107c13be9b',1,'FontxFile']]]
];
