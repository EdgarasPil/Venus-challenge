var structFontxFile =
[
    [ "bc", "structFontxFile.html#a2238ecad9dcd978769bd8265f099e195", null ],
    [ "file", "structFontxFile.html#acfa31c033f181df833797e43f817fe10", null ],
    [ "fsz", "structFontxFile.html#a6d68646b456c2f398c88f199e3f24b05", null ],
    [ "fxname", "structFontxFile.html#a9da66358e5f22eee0036da68e1a05ce7", null ],
    [ "h", "structFontxFile.html#ad86500492bc8041e8c60f897345e5839", null ],
    [ "is_ank", "structFontxFile.html#a8c88603516317fac8eee19b5049d3819", null ],
    [ "opened", "structFontxFile.html#abbe390075007bfcbf7b947107c13be9b", null ],
    [ "path", "structFontxFile.html#a8c21efef82bf756ad4b9ee7cb3664500", null ],
    [ "valid", "structFontxFile.html#ad6fc81f6599875ecb83510506bb4b870", null ],
    [ "w", "structFontxFile.html#a97fd8daec306150b33bbe29d658a571c", null ]
];