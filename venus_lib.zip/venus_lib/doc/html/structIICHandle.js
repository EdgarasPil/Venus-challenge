var structIICHandle =
[
    [ "addressed", "structIICHandle.html#a05f944939afd35dee7fd5f31c66ded5c", null ],
    [ "mem_handle", "structIICHandle.html#aadf4b2abce977a03980a46fdc108f1e0", null ],
    [ "new_val", "structIICHandle.html#acdd859854589b739e95f8bb12ca29507", null ],
    [ "ptr", "structIICHandle.html#afd48d8b51495844ee8199be241f174e4", null ],
    [ "recv_cnt", "structIICHandle.html#a4f1d79a2c727daa5fd550c583d1346c9", null ],
    [ "register_map", "structIICHandle.html#a2c15fa690e3eb23da32f2cc74fa4f524", null ],
    [ "register_map_length", "structIICHandle.html#aab287a7cac694af501effe315c280754", null ],
    [ "saddr", "structIICHandle.html#acab8c4b7f3d0e223b44e50dff075f096", null ],
    [ "selected_register", "structIICHandle.html#a3f5bfb1a421ccd59aab566aaae775618", null ],
    [ "state", "structIICHandle.html#aae3c59bd5da41093baf67a036b623a33", null ]
];