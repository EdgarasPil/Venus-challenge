var structpin =
[
    [ "channel", "structpin.html#ac01efb4bbda45e65d308aefe61e892a7", null ],
    [ "name", "structpin.html#a83d27e14d4dd6e48b483bb4a744eea00", null ],
    [ "state", "structpin.html#a537566db197746a6ba9d159733119aca", null ]
];