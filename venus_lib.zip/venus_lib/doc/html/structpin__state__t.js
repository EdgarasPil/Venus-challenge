var structpin__state__t =
[
    [ "channel", "structpin__state__t.html#aca29782c986ac13b0ba2c0825d9dd67f", null ],
    [ "level", "structpin__state__t.html#a3e9eeb6f90898cd0ec70d30ba98aa655", null ],
    [ "name", "structpin__state__t.html#a495d1da64ba88ecb831012debdb6dd7f", null ],
    [ "state", "structpin__state__t.html#ae0134f2312e63eb68f63791795e253c8", null ]
];