var switchbox_8c =
[
    [ "pin", "structpin.html", "structpin" ],
    [ "switchbox_destroy", "group__SWITCHBOX.html#ga3287b962efdc35dce05a4c0a6d899e61", null ],
    [ "switchbox_get_pin", "group__SWITCHBOX.html#ga33109c8bc1a5cbc80ed63ff9fe284c28", null ],
    [ "switchbox_init", "group__SWITCHBOX.html#gaa08d84687c6b7fcfae8d1ea0e067306f", null ],
    [ "switchbox_reset", "group__SWITCHBOX.html#ga74a66c9d9da08623ed4698e4ba7978a6", null ],
    [ "switchbox_set_pin", "group__SWITCHBOX.html#gadb0f900c7b5b5c0404844915b649e9b6", null ],
    [ "ioswitch", "switchbox_8c.html#ab2b7250f7c587c4f762accaea12eb148", null ],
    [ "ioswitch_handle", "switchbox_8c.html#af3add057b8db7797b5d5a1f5a6e1f38c", null ],
    [ "switchbox_names", "group__SWITCHBOX.html#gadae32edddacd3479e71db389361f59bc", null ]
];