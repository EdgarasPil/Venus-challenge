var uart_8h =
[
    [ "uart_index_t", "group__UART.html#ga45928ea0a0c86049068887d70beab0d3", [
      [ "UART0", "group__UART.html#gga45928ea0a0c86049068887d70beab0d3a9283de1a2e6eea552574a50ca586df8e", null ],
      [ "UART1", "group__UART.html#gga45928ea0a0c86049068887d70beab0d3ad78b5dd576e9a3ab80d6c77ff9d1cd27", null ],
      [ "NUM_UARTS", "group__UART.html#gga45928ea0a0c86049068887d70beab0d3a7e7cb082201c15a1b5d34c81b74bd69d", null ]
    ] ],
    [ "uart_destroy", "group__UART.html#ga167a88e937d80cff48567bb657f33577", null ],
    [ "uart_has_data", "group__UART.html#ga4471b179938b52d09adb413d69e09ebc", null ],
    [ "uart_has_space", "group__UART.html#ga584cca319fc3899cdcfdfbaf2f1dc0ba", null ],
    [ "uart_init", "group__UART.html#gaed068a60cfab2ede6bf62c524db8860e", null ],
    [ "uart_recv", "group__UART.html#ga6c42f275362e428d5ea415dcd6a4f74d", null ],
    [ "uart_reset_fifos", "group__UART.html#ga30646b4c6a0eac892062150f38756c8d", null ],
    [ "uart_send", "group__UART.html#gae1d74f3c7b13ce5f38c9c4d928669eba", null ]
];